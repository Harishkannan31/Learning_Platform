import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './coursePage.css';

function CourseList() {
  const [courses, setCourses] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchCourses = async () => {
      try {
        // Retrieve access token from local storage
        const accessToken = localStorage.getItem('accessToken');
        console.log("access token from course page from local storage", accessToken);
        if (!accessToken) {
          setError('Please log in to view courses.');
          return;
        }

        // Make a request to get details of the logged-in user
        const meResponse = await axios.get('http://localhost:8000/api/v1/me', {
          headers: {
            'access_token': accessToken
          }
        });
        console.log(meResponse.data)
        if (meResponse.data.user) {
          // If user details are returned, fetch courses
          const coursesResponse = await axios.get('http://localhost:8000/api/v1/get-all-courses', {
            headers: {
              'access_token': accessToken
            }
          });
          console.log(coursesResponse)
          setCourses(coursesResponse.data.courses);
        } else {
          // If user details are not returned, handle it accordingly
          setError('You are not authenticated. Please log in to view courses.');
        }
      } catch (error) {
        setError('Failed to fetch courses. Please try again later.');
        console.error('Error fetching courses:', error.message);
      }
    };

    fetchCourses();
  }, []);

  // Function to retrieve cookie by name
  const getCookie = (name) => {
    const cookieString = document.cookie;
    const cookies = cookieString.split(';');
    for (let cookie of cookies) {
      const [cookieName, cookieValue] = cookie.split('=');
      if (cookieName.trim() === name) {
        return cookieValue;
      }
    }
    return null;
  };

 // Function to display courses on the frontend
 const renderCourses = () => {
    if (!courses) {
        return <p>No courses available</p>;}
        return (
            <div>
              {/* <h2>Course List</h2> */}
              {courses.map(course => (
                <div key={course._id} className="course-card">
                  <h3>{course.name}</h3>
                  <p>Description: {course.description}</p>
                  <p>Price: {course.price}</p>
                  <p>Level: {course.level}</p>
                  <p>Prerequisites: {course.prerequisites.join(', ')}</p>
                  <p>Demo URL: <a href={course.demoUrl} target="_blank" rel="noopener noreferrer">{course.demoUrl}</a></p>
                  <p>Event Date: {course.Event_Date}</p>
                  <p>Event Time: {course.Event_Time}</p>
                  <p>Event Location: {course.Event_Location}</p>
                </div>
              ))}
            </div>
          );
        };
  
  return (
    <div>
      <h2>Course List</h2>
      {error && <p>{error}</p>}
      <div className="course-list">
        {renderCourses()}
      </div>
    </div>
  );
  }  

export default CourseList;
