import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom'; // Import useNavigate for navigation
import { MDBContainer, MDBCol, MDBRow, MDBBtn, MDBInput } from 'mdb-react-ui-kit';
import './signup.css';

function LoginForm() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const navigate = useNavigate(); // Get the navigate function from the hook

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8000/api/v1/login', formData);
      const { accessToken, user } = response.data;
      if (accessToken && user.role === 'admin' || 'user') {
        // Save the access token in local storage
        localStorage.setItem('accessToken', accessToken);
        // Navigate to the course page if the user is an admin
        navigate('/courses');
      } else {
        console.log('User is not an admin');
      }
    } catch (error) {
      console.error('Login failed:', error.message);
    }
  };
  

  return (
    <MDBContainer fluid className="p-3 my-5 h-custom">
      <MDBRow>
        <MDBCol col='10' md='6'>
          <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.webp" className="img-fluid" alt="Sample image" />
        </MDBCol>
        <MDBCol col='4' md='6'>
          <form onSubmit={handleLogin}>
            <div className="d-flex flex-row align-items-center justify-content-center">
              <p className="lead fw-normal mb-0 me-3">Log In</p>
            </div>
            <MDBInput
              wrapperClass='mb-4'
              label='Email address'
              id='emailInput'
              type='email'
              size="lg"
              name="email"
              value={formData.email}
              onChange={handleChange}
              required
            />
            <MDBInput
              wrapperClass='mb-4'
              label='Password'
              id='passwordInput'
              type='password'
              size="lg"
              name="password"
              value={formData.password}
              onChange={handleChange}
              required
            />
            <MDBBtn type="submit" className="mb-0 px-5 button" size='lg'>Login</MDBBtn>
          </form>
        </MDBCol>
      </MDBRow>
    </MDBContainer>
  );
}

export default LoginForm;
